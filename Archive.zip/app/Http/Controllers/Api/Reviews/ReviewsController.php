<?php

namespace App\Http\Controllers\Api\Reviews;

use App\Helper\ErrorHelperResponse;
use App\Http\Controllers\Controller;
use App\Http\Requests\Reviews\ReviewsPostRequest;
use App\Models\Review;
use App\Services\Reviews\ReviewService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Laravel\Sanctum\PersonalAccessToken;

class ReviewsController extends Controller
{
    public function reviews(){
        
        $reviews = Review::with('user')->where('status', true)->latest()->paginate(50);
        return response()->json($reviews, Response::HTTP_OK);
    }
    public function reviewsList(){
        $reviews = Review::with('user')->latest()->paginate(50);
        return response()->json($reviews, Response::HTTP_OK);
    }
    public function reviewsPost(ReviewsPostRequest $request, ReviewService $reviewService){
        
        $user = false;
        if(isset($request->header()['authorization'])){
            $token = PersonalAccessToken::findToken(explode(' ',$request->header()['authorization'][0])[1]);
            if($token){
                $user= $token->tokenable;
               
            }
           
        }
       
        return $reviewService->reviewPost($request->validated(),$user);
    }
    public function reviewsEdit(ReviewsPostRequest $request, ReviewService $reviewService, $id){
        return $reviewService->reviewEdit($request->validated(),$id);
    }
    public function reviewsDelete($id){
        $reviews = Review::find($id);
        if(!$reviews){
            $lang['ru']= 'Не найден';
            $lang['uz']= 'Topilmadi';
            return ErrorHelperResponse::returnError($lang,Response::HTTP_NOT_FOUND);
        } 
        try {
            
            $reviews->delete();
            $lang['ru']= 'Удален';
            $lang['uz']= 'O`chirildi';
            return response()->json($lang, Response::HTTP_OK);
        } catch (\Throwable $th) {
            $lang['ru']= 'Ошибка';
            $lang['uz']= 'Xatolik';
            return ErrorHelperResponse::returnError($lang,Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }
    public function reviewsChangeStatus($id){
        $reviews = Review::find($id);
        if(!$reviews){
            $lang['ru']= 'Не найден';
            $lang['uz']= 'Topilmadi';
            return ErrorHelperResponse::returnError($lang,Response::HTTP_NOT_FOUND);
        }
        try {
            $reviews->status = !$reviews->status;
            $reviews->save();
            $lang['ru']= 'Обновлен';
            $lang['uz']= 'Yangilandi';
            return response()->json($lang, Response::HTTP_OK);
        } catch (\Throwable $th) {
            $lang['ru']= 'Ошибка: '.$th->getMessage();
            $lang['uz']= 'Xatolik: '.$th->getMessage();
            return ErrorHelperResponse::returnError($lang,Response::HTTP_UNPROCESSABLE_ENTITY);
        } 
    }
}
